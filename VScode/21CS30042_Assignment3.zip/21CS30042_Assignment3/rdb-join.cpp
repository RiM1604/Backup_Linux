
Relation * naturaljoin(Relation * R1, Relation * R2, list<string>joinattr)
{

};